<?php

return [
    'name' => 'Merchant'
];
