<?php

return [
    'name' => 'Membership'
];
