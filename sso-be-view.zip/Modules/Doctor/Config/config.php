<?php

return [
    'name' => 'Doctor'
];
