<?php

return [
    'name' => 'Consultation'
];
