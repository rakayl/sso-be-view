<?php

return [
    'name' => 'PaymentMethod'
];
