<?php

return [
    'name' => 'Enquiries'
];
