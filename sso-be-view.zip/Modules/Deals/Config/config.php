<?php

return [
    'name' => 'Deals'
];
