<?php

return [
    'name' => 'DeliveryService'
];
