<div class="page-footer-inner"> 
</div>
<div class="scroll-to-top">
	<i class="icon-arrow-up"></i>
</div>