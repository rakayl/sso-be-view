<?php

return [
    'name' => 'CustomPage'
];
