<?php

return [
    'name' => 'InboxGlobal'
];
