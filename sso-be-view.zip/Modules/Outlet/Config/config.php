<?php

return [
    'name' => 'Outlet'
];
