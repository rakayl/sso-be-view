<?php

return [
    'name' => 'PointInjection'
];
