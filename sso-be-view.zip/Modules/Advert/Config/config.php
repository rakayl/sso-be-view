<?php

return [
    'name' => 'Advert'
];
